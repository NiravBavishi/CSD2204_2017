//
//  SpilitPickerViewController.swift
//  noName
//
//  Created by MacStudent on 2017-10-19.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class SpilitPickerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
   
     var countryNameList = [String]()
    
    var JobList = [String]()
    
    @IBOutlet weak var lblLabel1: UILabel!
    
    @IBOutlet weak var splitPickerView: UIPickerView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        splitPickerView.dataSource = self
        splitPickerView.delegate = self
        
        // Do any additional setup after loading the view.
        
         countryNameList = ["India","Canada","USA","Pakistan","UK","France","Srilanka","Mexico","South Africa","China", "Bhutan","Singapor"]
        
        JobList = ["IOS Programming", "Android Programming", "C","C++","Java",".NET","ASP.NET"]
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    
        let size : Int = 0
        
        
        if component == 0{
        return countryNameList.count
        }else if component == 1{
        return JobList.count
        }else{
            
            return size
            
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    
        let size : String = ""
        
        if component == 0 {
        return countryNameList[row]
        }else if component == 1 {
        return JobList[row]
        }else {
            
            return size
            
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lblLabel1.text = "\( countryNameList[splitPickerView.selectedRow(inComponent: 0)]) And \(JobList[splitPickerView.selectedRow(inComponent: 1)])"
    }
    
    
    

}
