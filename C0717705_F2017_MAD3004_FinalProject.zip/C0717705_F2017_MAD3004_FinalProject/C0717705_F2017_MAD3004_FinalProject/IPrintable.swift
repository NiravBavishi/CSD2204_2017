//
//  IPrintable.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-10.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


protocol IPrintable {
    
    func printMyData() -> String
    
}




