//
//  ViewController.swift
//  Navigation[Day-04]
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSubmit(_ sender: UIButton) {
        
        let userName = "Nirav"
        let password = "Nirav@123"
        
        if (txtUserName.text == userName && txtPassword.text == password) {
            
            print("Nirav")
            
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let EmployeeViewController = storyBoard.instantiateViewController(withIdentifier: "EmployeeScreen") as! EmployeeViewController
            self.present(EmployeeViewController, animated: true, completion: nil)
            
        }
        else {
            
            print("Not Ok")
            
        }
        
    }
    
}

