//
//  EmpDataViewController.swift
//  Navigation[Day-04]
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class EmpDataViewController: UIViewController {

    
    @IBOutlet weak var lblData: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var PrintData = ""
        
        
        
        for (key,value) in Employee.employeeList{
            
        var emp  = Employee.employeeList[key]
            
            PrintData += "\(emp?.empId!) --- \(emp?.empName!)"
            
        }
        lblData.text = PrintData
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
