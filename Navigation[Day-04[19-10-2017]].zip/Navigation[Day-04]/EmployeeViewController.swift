//
//  EmployeeViewController.swift
//  Navigation[Day-04]
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class EmployeeViewController: UIViewController {

    
    @IBOutlet weak var txtEmpId: UITextField!
    @IBOutlet weak var txtEmpName: UITextField!
    @IBOutlet weak var txtEmpBirthDate: UITextField!
    @IBOutlet weak var txtEmpSalary: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func btnSave(_ sender: UIButton) {
        
        let emp = Employee()
        
        emp.empId = Int(txtEmpId.text!)
        emp.empName = txtEmpName.text
        
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        emp.bierthDate = dateFormatter.date(from: txtEmpBirthDate.text!)
        
        
        emp.salary = Double(txtEmpSalary.text!)
        
        
        let flag = Employee.addEmployee(emp: emp)
        if flag {
            
            let alert = UIAlertController(title: "Message", message: "Employee Date Saved", preferredStyle: UIAlertControllerStyle.alert)
            
            alert.addAction( UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            print("Employee record Saved")
              self.present(alert, animated: true, completion: nil)
        }else{
            
            print("Possible duplication error !")
            
        }
        
    }
}
