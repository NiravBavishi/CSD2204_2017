//
//  PartTime.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


public class PartTime: Employee {
    
    public var hourlyRate : Int
    public var numberHoursWorked : Int
    
    override init() {
        hourlyRate = 0
        numberHoursWorked = 0
        super.init();
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int) {
        hourlyRate = pHourlyRate
        numberHoursWorked = pNumberHoursWorked
        super.init(ppName, ppAge)
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int, ppV: Vehicle) {
        hourlyRate = pHourlyRate
        numberHoursWorked = pNumberHoursWorked
        super.init(ppName, ppAge, ppV)
    }
    
    
    override func calcEarnings() -> Double {
        return Double(numberHoursWorked * hourlyRate)
    }
    
    override func printMyData() -> String {
        //super.printMyData()
        
        if(self is CommissionBasedPartTime){
            
            return "Employee Is PartTime / Commissioned \nRate : \(hourlyRate)\nHours Worked: \(numberHoursWorked)"
        } else if(self is FixedBasedPartTime) {
            
            return "Employee Is PartTime / Fixed Amount \nRate : \(hourlyRate)\nHours Worked: \(numberHoursWorked)"
        }
        else {
            
            return "Name : \(name) \nBirth Year : \(calcBirthYear()) \n" + (v?.printMyData())!
            
        }
        
        /* print ("Rate: \(hourlyRate)")
         print ("Hours Worked: \(numberHoursWorked)")*/
    }
    
    
    
    
    
}
