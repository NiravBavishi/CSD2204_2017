//
//  FullTime.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


public class FullTime : Employee {
    public var salary : Int
    public var bonus : Int
    
    override init() {
        salary = 0
        bonus = 0
        super.init();
    }
    
    init(ppName: String, ppAge: Int, pSalary: Int, pBonus: Int) {
        salary = pSalary
        bonus = pBonus
        super.init(ppName, ppAge)
    }
    
    init(ppName: String, ppAge: Int, pSalary: Int, pBonus: Int, ppV: Vehicle) {
        salary = pSalary
        bonus = pBonus
        super.init(ppName, ppAge, ppV)
    }
    
    
    override func calcEarnings() -> Double {
        return Double(salary + bonus)
    }
    
    override func printMyData() -> String {
        //super.printMyData()
        
        var sr = "Namne : \(name) \nBirth Year : \(calcBirthYear()) \nEmployee Is FullTime \nSalary: \(salary) \nBonus: \(bonus) \n" + (v?.printMyData())!
        
        if(self.v is Car) {
            
            sr += "\nEmployee Has Car"
        } else if (self.v is Motorcycle) {
            
            sr += "\nEmployee Has Motorcycle"
            
        }
        else {
            
            sr += "\nEmployee Has No Car"
            
        }
        
        return sr
        
        /*print ("Salary: \(salary)")
         print ("Bonus: \(bonus)")*/
    }
    
    
    
    
}


