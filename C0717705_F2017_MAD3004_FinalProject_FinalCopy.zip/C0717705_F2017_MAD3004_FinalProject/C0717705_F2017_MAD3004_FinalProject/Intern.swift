//
//  Intern.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


public class Intern : Employee {
    public var schoolName : String
    
    override init() {
        schoolName = ""
        super.init()
    }
    
    init(pName: String, pAge: Int, pSchool: String) {
        schoolName = pSchool
        super.init(pName, pAge)
    }
    
    init(pName: String, pAge: Int, pSchool: String, ppV: Vehicle) {
        schoolName = pSchool
        super.init(pName, pAge, ppV)
    }
    
    
    override func printMyData() -> String {
        /* super.printMyData()
         print ("School Name: \(schoolName)")*/
        
        return "Name : \(name) \nBirth Year : \(calcBirthYear()) \nSchool Name : \(schoolName)"
        
    }
    
}



