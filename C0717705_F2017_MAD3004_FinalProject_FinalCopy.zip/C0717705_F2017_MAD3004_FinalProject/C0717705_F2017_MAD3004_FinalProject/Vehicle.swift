//
//  Vehicle.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


public class Vehicle : IPrintable {
    public var make: String
    public var model: String
    
    init() {
        make = ""
        model = ""
    }
    
    init(pMake: String, pModel: String) {
        make = pMake
        model = pModel
    }
    
    func printMyData() -> String {
        
        return " - Make : \(make) \n - Model : \(model)"
        
    }
}




