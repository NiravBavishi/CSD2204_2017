//
//  Employee.swift
//  C0717705_F2017_MAD3004_FinalProject
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


public class Employee : IPrintable{
    public var name: String
    public var  age: Int
    public var v: Vehicle? // optional
    
    //    func setAge(pAge: Int) {
    //        if pAge >= 0 {
    //           age = pAge
    //        } else {
    //            age = 0
    //        }
    //    }
    //
    //    func getAge() -> Int {
    //        return self.age
    //    }
    
    init() {
        name = ""
        age = 0
        v = nil
    }
    
    init (_ pName: String,_ pAge: Int) {
        name = pName
        age = pAge
        v = nil
    }
    
    init (_ pName: String,_ pAge: Int, _ pV: Vehicle) {
        name = pName
        age = pAge
        v = pV
    }
    
    
    /*func calcBirthYear() -> Int {
        return (2017 - self.age)
    }*/
    
    func calcEarnings() -> Double {
        return 1000.00
    }
    
    func printMyData() -> String {
        
        return "Name: \(name) \nBirth Year : \(calcBirthYear())"
        //print ("Birth Year: " + String(e1.calcBirthYear()))
        /*print ("Name: \(name)")
         print ("Age: \(age)")*/
        
    }
    
    
    
    func calcBirthYear() -> Int{
     
     let date = Date()
     let calendar = Calendar.current
     let year = calendar.component(.year, from: date)
     
     return (year - age)
     
     }
    
}





