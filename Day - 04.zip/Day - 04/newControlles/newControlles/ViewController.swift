//
//  ViewController.swift
//  newControlles
//
//  Created by MacStudent on 2017-10-17.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var segmentAnimals: UISegmentedControl!
    @IBOutlet weak var lblPrintData: UILabel!
    @IBOutlet weak var lblSteper: UILabel!
    
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var Image: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.segmentAnimals.insertSegment(withTitle: "Elephant", at: 3, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func mySegmentClick(_ sender: UISegmentedControl) {
        
       if sender.selectedSegmentIndex == 0 {
            
            lblPrintData.text = "Lion"
        Image.image = UIImage(named : "Lion")
        
            
        }else if sender.selectedSegmentIndex == 1 {
            
            lblPrintData.text = "Tiger"
        Image.image = UIImage(named : "Tiger")
            
        }
        else if sender.selectedSegmentIndex == 2 {
            
            lblPrintData.text = "Cat"
        Image.image = UIImage(named : "Cat")
            
        }
       else if sender.selectedSegmentIndex == 3 {
        
        lblPrintData.text = "Elephant"
        Image.image = UIImage(named : "Elephant")
        
        }
        
    }
    
    @IBAction func mySteperClick(_ sender: UIStepper) {
        
        lblSteper.text = String(sender.value)
        
    }
    @IBAction func datePicker(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, MMM d, yyyy"
        lblDate.text = dateFormatter.string(from: sender.date)
        
        dateFormatter.locale = Locale(identifier: "en_US")
        print(dateFormatter.string(from: sender.date)) // Jan 2, 2001
        
        
        //lblDate.text =  String(describing: sender.date)
        
    }
    
    
}

