//
//  StoreViewController.swift
//  newControlles
//
//  Created by MacStudent on 2017-10-17.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class StoreViewController: UIViewController {

    
    @IBOutlet weak var txtfldUserName: UITextField!
    @IBOutlet weak var txtfldPassword: UITextField!
    @IBOutlet weak var switchremember: UISwitch!
    
    
    var myUserDefaults : UserDefaults!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        myUserDefaults = UserDefaults.standard
        if let userName = myUserDefaults.value(forKey: "userName"){
            
            txtfldUserName.text = userName as? String
            
        }
        if let password = myUserDefaults.value(forKey: "password"){
            
            txtfldPassword.text = password as? String
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func btnSubmit(_ sender: UIButton) {
        let UserName = "Nirav"
        let UserPassword = "Nirav"
        
        if (txtfldUserName.text == UserName && txtfldPassword.text == UserPassword){
        
        if switchremember.isOn {
            
            print("Switch is On")
            self.myUserDefaults.set(txtfldUserName, forKey: "userName")
            self.myUserDefaults.set(txtfldPassword, forKey: "password")
            
        }
        else {
            
            print("Switch is Off")
            self.myUserDefaults.removeObject(forKey: "userName")
            self.myUserDefaults.removeObject(forKey: "password")
            
        }
        }
        else{
            
            var alert = UIAlertController(title: "Message", message: "Incorrect Login credentials", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title:"Ok", style :  UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
}
